#!/bin/bash
java -jar ./HummingbirdArdublockInstaller.jar
